# Data Sources

All datasets are fetched **at runtime** from public URLs.
No manual downloads are required to reproduce the analysis.

---

## 1. Bloom & Neher (2023) Fitness Estimates

**File:** `aamut_fitness_all.csv`  
**Source:** https://github.com/jbloomlab/SARS2-mut-fitness  
**Direct URL used in code:**
```
https://raw.githubusercontent.com/jbloomlab/SARS2-mut-fitness/main/results/aa_fitness/aamut_fitness_all.csv
```

**Key columns used:**

| Column | Description |
|--------|-------------|
| `gene` | SARS-CoV-2 gene name (e.g. `S`, `nsp5`) |
| `aa_site` | Amino acid position |
| `mutant_aa` | Mutant amino acid (single letter) |
| `delta_fitness` | Sequence-based fitness effect |
| `expected_count` | Expected barcode counts; used for filtering |

**Filtering:** Notebook 03 keeps only mutations with `expected_count >= 20`
(matching the paper's Figure 4). Notebook 04 keeps all mutations and uses
`expected_count` as a weight instead.

---

## 2. Spike DMS — Dadonaite et al. (2023)

**Source:** https://github.com/dms-vep/SARS-CoV-2_Omicron_BA.1_spike_DMS_mAbs  
**Files fetched:**

| File | URL path |
|------|----------|
| Barcode-variant table | `results/variants/codon_variants.csv` |
| Variant counts | `results/variant_counts/*.csv` |

**Sample files used:**
- Input (pre-selection): `VSVG_control_1.csv`, `VSVG_control_2.csv`
- Output (post-selection): `no-antibody_control_*.csv`

---

## 3. Mpro DMS — Flynn et al. (2022)

**Source:** eLife article 77433  
**Direct URL:**
```
https://cdn.elifesciences.org/articles/77433/elife-77433-fig2-data1-v2.xlsx
```

This Excel file contains multiple sheets, one per functional assay.
The code merges all sheets on `(position, mutation)` and averages the scores.

---

## Reproducibility Note

If any URL becomes unavailable, cached copies can be obtained from:
- **Zenodo** (search for the paper DOI)
- **Wayback Machine** (archive.org)

In that case, save the file locally and update the URL variable in the
relevant notebook cell.
