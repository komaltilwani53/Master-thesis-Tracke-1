"""
fitness_utils.py
================
Core utility functions shared across notebooks.

Functions
---------
parse_mut(s)
    Parse a mutation string like 'N501Y' into (wt_aa, site, mut_aa).

safe_panel(ax, x_vals, y_vals, title, xlabel, ylabel)
    Scatter + regression + Pearson r annotation on a matplotlib Axes.

weighted_pearson(x, y, w)
    Pearson correlation weighted by array w.

load_fitness_estimates(url, min_expected_count)
    Fetch and filter the Bloom & Neher fitness CSV.
"""

import re
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from scipy import stats


# ---------------------------------------------------------------------------
# Mutation string parsing
# ---------------------------------------------------------------------------

def parse_mut(s):
    """
    Parse a mutation string, e.g. 'N501Y', into its components.

    Parameters
    ----------
    s : str or NaN
        Mutation string in the format <WT><site><MUT>, e.g. 'N501Y'.

    Returns
    -------
    tuple : (wt_aa, site, mut_aa)
        wt_aa  – wild-type single-letter amino acid (str)
        site   – residue position (int)
        mut_aa – mutant single-letter amino acid or '*' for stop (str)
        Returns (np.nan, np.nan, np.nan) on parse failure.
    """
    if pd.isna(s):
        return np.nan, np.nan, np.nan
    m = re.match(r'([A-Z])(\d+)([A-Z*])', str(s))
    if not m:
        return np.nan, np.nan, np.nan
    return m.group(1), int(m.group(2)), m.group(3)


# ---------------------------------------------------------------------------
# Plotting helpers
# ---------------------------------------------------------------------------

def safe_panel(ax, x_vals, y_vals, title, xlabel, ylabel, weights=None):
    """
    Plot a scatter panel with a linear regression line and Pearson r.

    Handles NaN / Inf values by masking them out.  If fewer than 2 finite
    data points remain, a 'NO DATA' message is shown instead.

    Parameters
    ----------
    ax : matplotlib.axes.Axes
    x_vals, y_vals : array-like
    title, xlabel, ylabel : str
    weights : array-like or None
        If provided, compute a weighted Pearson r (for the annotation only;
        the regression line is always OLS).
    """
    x = np.asarray(x_vals, dtype=float)
    y = np.asarray(y_vals, dtype=float)
    mask = np.isfinite(x) & np.isfinite(y)

    if weights is not None:
        w = np.asarray(weights, dtype=float)
        mask &= np.isfinite(w) & (w > 0)
        x, y, w = x[mask], y[mask], w[mask]
    else:
        x, y = x[mask], y[mask]

    if len(x) < 2:
        ax.text(0.5, 0.5, f"NO DATA (n={len(x)})",
                transform=ax.transAxes, ha="center", va="center",
                fontsize=12, color="red")
        ax.set_title(title + " — NO DATA")
        return

    if weights is not None:
        r = weighted_pearson(x, y, w)
    else:
        r, _ = stats.pearsonr(x, y)

    ax.scatter(x, y, alpha=0.3, s=10, color="steelblue")
    m, b = np.polyfit(x, y, 1)
    xline = np.linspace(x.min(), x.max(), 100)
    ax.plot(xline, m * xline + b, color="darkorange", linewidth=2)
    ax.set_xlabel(xlabel, fontsize=11)
    ax.set_ylabel(ylabel, fontsize=11)
    ax.set_title(title, fontsize=12)
    ax.text(0.05, 0.95, f"r = {r:.3f}\nn = {len(x)}",
            transform=ax.transAxes, va="top",
            color="darkorange", fontsize=11)
    print(f"  {title}: r={r:.3f}, n={len(x)}")


# ---------------------------------------------------------------------------
# Weighted Pearson correlation
# ---------------------------------------------------------------------------

def weighted_pearson(x, y, w):
    """
    Compute a weighted Pearson correlation coefficient.

    Parameters
    ----------
    x, y, w : array-like
        Data arrays and weights. All must have the same length.
        NaN / Inf / non-positive weights are masked out.

    Returns
    -------
    float : weighted Pearson r
    """
    w = np.asarray(w, dtype=float)
    x = np.asarray(x, dtype=float)
    y = np.asarray(y, dtype=float)
    mask = np.isfinite(x) & np.isfinite(y) & np.isfinite(w) & (w > 0)
    x, y, w = x[mask], y[mask], w[mask]

    w_sum  = w.sum()
    x_mean = (w * x).sum() / w_sum
    y_mean = (w * y).sum() / w_sum
    cov_xy = (w * (x - x_mean) * (y - y_mean)).sum() / w_sum
    var_x  = (w * (x - x_mean) ** 2).sum() / w_sum
    var_y  = (w * (y - y_mean) ** 2).sum() / w_sum

    if var_x <= 0 or var_y <= 0:
        return np.nan
    return cov_xy / np.sqrt(var_x * var_y)


# ---------------------------------------------------------------------------
# Data loading helpers
# ---------------------------------------------------------------------------

def load_fitness_estimates(
    url=(
        "https://raw.githubusercontent.com/jbloomlab/SARS2-mut-fitness"
        "/main/results/aa_fitness/aamut_fitness_all.csv"
    ),
    min_expected_count=20,
):
    """
    Fetch the Bloom & Neher fitness CSV and apply the expected-count filter.

    Parameters
    ----------
    url : str
        Raw CSV URL (default: main branch of jbloomlab/SARS2-mut-fitness).
    min_expected_count : int or None
        If an integer, keep only rows where expected_count >= this value.
        Pass None to keep all rows (for the EnrichR2 approach).

    Returns
    -------
    pd.DataFrame
        Columns (lowercase): gene, aa_site, mutant_aa, delta_fitness,
        expected_count, …
    """
    df = pd.read_csv(url)
    df.columns = df.columns.str.lower()
    if min_expected_count is not None:
        df = df[df["expected_count"] >= min_expected_count].copy()
    return df
