"""
dms_processing.py
=================
Functions for loading and processing DMS barcode count data
from the Dadonaite et al. (2023) Spike deep mutational scanning dataset.

Functions
---------
load_barcode_variant_table(url)
    Fetch the barcode → variant lookup table.

load_variant_counts(repo, raw_base)
    Fetch all per-sample variant-count CSVs from a GitHub repository.

split_input_output(counts_df, input_pattern, output_pattern)
    Split counts into input (pre-selection) and output (post-selection).

merge_counts_with_variants(input_counts, output_counts, bv_table)
    Inner-join count tables with the barcode-variant table.

compute_log2_enrichment(merged, pseudocount)
    Compute per-barcode log2 enrichment scores.

normalise_scores(spike_scores, wt_mean, stop_mean)
    Rescale so that WT = 0 and stop codon = -1.

compute_enrichR2_scores(counts_df, bv_table,
                        input_pattern, output_pattern, pseudocount)
    Full EnrichR2 pipeline: inverse-variance weighted scores per mutation.
"""

import requests
import numpy as np
import pandas as pd


# ---------------------------------------------------------------------------
# Data loading
# ---------------------------------------------------------------------------

SPIKE_BV_URL = (
    "https://raw.githubusercontent.com/dms-vep/"
    "SARS-CoV-2_Omicron_BA.1_spike_DMS_mAbs/main/"
    "results/variants/codon_variants.csv"
)

SPIKE_REPO    = "dms-vep/SARS-CoV-2_Omicron_BA.1_spike_DMS_mAbs"
SPIKE_RAW_BASE = (
    "https://raw.githubusercontent.com/"
    "dms-vep/SARS-CoV-2_Omicron_BA.1_spike_DMS_mAbs/"
    "main/results/variant_counts/"
)


def load_barcode_variant_table(url=SPIKE_BV_URL):
    """
    Fetch the barcode-to-variant lookup table.

    Parameters
    ----------
    url : str
        URL of the codon_variants CSV.

    Returns
    -------
    pd.DataFrame
        Columns include: barcode, library, aa_substitutions,
        n_aa_substitutions.
    """
    df = pd.read_csv(url)
    print(f"Barcode-variant table: {df.shape[0]:,} rows, "
          f"columns: {df.columns.tolist()}")
    return df


def load_variant_counts(
    repo=SPIKE_REPO,
    raw_base=SPIKE_RAW_BASE,
):
    """
    Fetch all variant-count CSVs from the GitHub repository's
    results/variant_counts/ directory via the GitHub Contents API.

    Parameters
    ----------
    repo : str
        GitHub repo in 'owner/repo' format.
    raw_base : str
        Raw-content base URL for the variant_counts directory.

    Returns
    -------
    pd.DataFrame
        Concatenated counts with an added 'sample_file' column.
    """
    api_url = f"https://api.github.com/repos/{repo}/contents/results/variant_counts"
    response = requests.get(api_url)
    if response.status_code != 200:
        raise RuntimeError(f"GitHub API error {response.status_code}: {api_url}")

    files = [f["name"] for f in response.json() if f["name"].endswith(".csv")]
    print(f"Files found: {len(files)}")

    all_counts = []
    for fname in files:
        try:
            df = pd.read_csv(raw_base + fname)
            df["sample_file"] = fname
            all_counts.append(df)
        except Exception as exc:
            print(f"  SKIP {fname}: {exc}")

    counts_df = pd.concat(all_counts, ignore_index=True)
    print(f"counts_df: {counts_df.shape[0]:,} rows, "
          f"samples: {counts_df['sample_file'].nunique()}")
    return counts_df


# ---------------------------------------------------------------------------
# Processing
# ---------------------------------------------------------------------------

def split_input_output(
    counts_df,
    input_pattern="VSVG_control",
    output_pattern="no-antibody_control",
):
    """
    Aggregate barcode counts for input and output samples separately.

    Parameters
    ----------
    counts_df : pd.DataFrame
        Contains columns 'barcode', 'count', 'sample_file'.
    input_pattern, output_pattern : str
        Substrings to match against 'sample_file'.

    Returns
    -------
    (input_counts, output_counts) : tuple of pd.DataFrames
        Each has columns: barcode, count_input / count_output.
    """
    input_mask  = counts_df["sample_file"].str.contains(input_pattern)
    output_mask = counts_df["sample_file"].str.contains(output_pattern)

    assert input_mask.sum()  > 0, f"No files matched input pattern '{input_pattern}'"
    assert output_mask.sum() > 0, f"No files matched output pattern '{output_pattern}'"

    input_counts = (
        counts_df[input_mask]
        .groupby("barcode")["count"].sum()
        .reset_index()
        .rename(columns={"count": "count_input"})
    )
    output_counts = (
        counts_df[output_mask]
        .groupby("barcode")["count"].sum()
        .reset_index()
        .rename(columns={"count": "count_output"})
    )

    print(f"Input barcodes: {len(input_counts):,}")
    print(f"Output barcodes: {len(output_counts):,}")
    return input_counts, output_counts


def merge_counts_with_variants(input_counts, output_counts, bv_table):
    """
    Inner-join input + output counts with the barcode-variant table.

    Parameters
    ----------
    input_counts, output_counts : pd.DataFrames
        From split_input_output().
    bv_table : pd.DataFrame
        From load_barcode_variant_table().

    Returns
    -------
    pd.DataFrame
        Columns: barcode, count_input, count_output,
                 library, aa_substitutions, n_aa_substitutions.
    """
    merged = input_counts.merge(output_counts, on="barcode", how="inner")
    merged = merged.merge(
        bv_table[["barcode", "library", "aa_substitutions", "n_aa_substitutions"]],
        on="barcode",
        how="inner",
    )
    assert len(merged) > 0, (
        "Merge produced 0 rows. "
        f"bv_table columns: {bv_table.columns.tolist()}"
    )
    print(f"Merged shape: {merged.shape}")
    return merged


def compute_log2_enrichment(merged, pseudocount=0.5):
    """
    Compute log2 enrichment scores for single-amino-acid substitutions
    and return per-mutation mean ± barcode count.

    Parameters
    ----------
    merged : pd.DataFrame
        From merge_counts_with_variants().
    pseudocount : float
        Added to counts before frequency calculation to avoid log(0).

    Returns
    -------
    spike_scores : pd.DataFrame
        Columns: aa_substitutions, dms_score, n_barcodes.
    wt_mean, stop_mean : float
        Raw mean log2 enrichment for WT and stop-codon barcodes
        (used for normalisation).
    """
    single_muts = merged[merged["n_aa_substitutions"] == 1].copy()
    print(f"Single mutants: {len(single_muts):,}")

    total_input  = single_muts["count_input"].sum()
    total_output = single_muts["count_output"].sum()

    single_muts["freq_input"]  = (single_muts["count_input"]  + pseudocount) / (total_input  + pseudocount)
    single_muts["freq_output"] = (single_muts["count_output"] + pseudocount) / (total_output + pseudocount)
    single_muts["log2_enrich"] = np.log2(single_muts["freq_output"] / single_muts["freq_input"])

    spike_scores = (
        single_muts
        .groupby("aa_substitutions")["log2_enrich"]
        .agg(["mean", "count"])
        .reset_index()
        .rename(columns={"mean": "dms_score", "count": "n_barcodes"})
    )

    # WT and stop-codon reference values
    wt   = merged[merged["n_aa_substitutions"] == 0].copy()
    stop = merged[merged["aa_substitutions"].str.contains(r"\*", na=False)].copy()

    for df in [wt, stop]:
        df["freq_input"]  = (df["count_input"]  + pseudocount) / (total_input  + pseudocount)
        df["freq_output"] = (df["count_output"] + pseudocount) / (total_output + pseudocount)
        df["log2_enrich"] = np.log2(df["freq_output"] / df["freq_input"])

    wt_mean   = wt["log2_enrich"].mean()
    stop_mean = stop["log2_enrich"].mean()
    print(f"wt_mean={wt_mean:.4f}  stop_mean={stop_mean:.4f}")

    return spike_scores, wt_mean, stop_mean


def normalise_scores(spike_scores, wt_mean, stop_mean, min_barcodes=3):
    """
    Rescale DMS scores so that WT = 0 and stop codon = -1.

    Parameters
    ----------
    spike_scores : pd.DataFrame
        From compute_log2_enrichment(); must have columns
        'dms_score' and 'n_barcodes'.
    wt_mean, stop_mean : float
        From compute_log2_enrichment().
    min_barcodes : int
        Minimum number of supporting barcodes to retain a mutation.

    Returns
    -------
    pd.DataFrame
        Input DataFrame with an additional 'dms_score_norm' column,
        filtered to mutations with n_barcodes >= min_barcodes.
    """
    spike_scores = spike_scores.copy()
    spike_scores["dms_score_norm"] = (
        (spike_scores["dms_score"] - wt_mean) / (wt_mean - stop_mean)
    )
    spike_scores = spike_scores[spike_scores["n_barcodes"] >= min_barcodes]
    print(f"Mutations after normalisation: {len(spike_scores):,}")
    return spike_scores


# ---------------------------------------------------------------------------
# EnrichR2 pipeline
# ---------------------------------------------------------------------------

def compute_enrichR2_scores(
    counts_df,
    bv_table,
    input_pattern="VSVG_control",
    output_pattern="no-antibody_control",
    pseudocount=0.5,
):
    """
    Full EnrichR2 pipeline: inverse-variance weighted mean per mutation.

    Instead of a simple mean of log2 enrichments, each barcode is
    weighted by the inverse of its estimated variance:

        var_i ≈ 1/count_out_i + 1/count_in_i   (delta-method approximation)
        weight_i = 1 / var_i

    This naturally down-weights low-count barcodes without discarding them.

    Parameters
    ----------
    counts_df : pd.DataFrame
        From load_variant_counts(); columns: barcode, count, sample_file.
    bv_table : pd.DataFrame
        From load_barcode_variant_table().
    input_pattern, output_pattern : str
        Substrings to match in 'sample_file'.
    pseudocount : float

    Returns
    -------
    pd.DataFrame
        Columns: aa_substitutions, enrichR2_score, sum_weight, n_barcodes.
    """
    input_counts, output_counts = split_input_output(
        counts_df, input_pattern, output_pattern
    )
    merged = merge_counts_with_variants(input_counts, output_counts, bv_table)
    single_muts = merged[merged["n_aa_substitutions"] == 1].copy()

    total_input  = single_muts["count_input"].sum()
    total_output = single_muts["count_output"].sum()

    single_muts["freq_input"]  = (single_muts["count_input"]  + pseudocount) / (total_input  + pseudocount)
    single_muts["freq_output"] = (single_muts["count_output"] + pseudocount) / (total_output + pseudocount)
    single_muts["log2_enrich"] = np.log2(single_muts["freq_output"] / single_muts["freq_input"])

    # Inverse-variance weight
    single_muts["var_i"]    = (1.0 / (single_muts["count_output"] + pseudocount)
                               + 1.0 / (single_muts["count_input"]  + pseudocount))
    single_muts["weight_i"] = 1.0 / single_muts["var_i"]

    def weighted_mean(g):
        w = g["weight_i"]
        return (g["log2_enrich"] * w).sum() / w.sum()

    enrichR2 = (
        single_muts
        .groupby("aa_substitutions")
        .apply(lambda g: pd.Series({
            "enrichR2_score": weighted_mean(g),
            "sum_weight":     g["weight_i"].sum(),
            "n_barcodes":     len(g),
        }))
        .reset_index()
    )
    print(f"EnrichR2 mutations: {len(enrichR2):,}")
    return enrichR2
