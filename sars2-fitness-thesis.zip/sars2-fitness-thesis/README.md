# SARS-CoV-2 Mutation Fitness — Master's Thesis

Reproduction and extension of **Bloom & Neher (2023)** Figure 4:
*"Fitness effects of mutations to SARS-CoV-2 proteins"*

This repository contains all code required to reproduce the DMS-vs-fitness
correlation analysis and the EnrichR2-weighted extension developed in the
thesis.

---

## Quick-Start (≤ 5 minutes)

```bash
# 1. Clone
git clone https://github.com/<your-username>/sars2-fitness-thesis.git
cd sars2-fitness-thesis

# 2. Create environment
conda env create -f environment.yml
conda activate sars2-fitness

# — OR — plain pip:
pip install -r requirements.txt

# 3. Run the reproduction notebook
jupyter lab notebooks/03_dms_reproduction.ipynb

# 4. Run the EnrichR2 extension
jupyter lab notebooks/04_enrichr2_analysis.ipynb
```

All data are fetched automatically from public GitHub/eLife URLs — no manual
downloads required.

---

## Repository Structure

```
sars2-fitness-thesis/
├── README.md                    ← You are here
├── requirements.txt             ← pip dependencies
├── environment.yml              ← conda environment
│
├── notebooks/
│   ├── 01_data_exploration.ipynb        ← Initial data inspection
│   ├── 02_mutation_counts_analysis.ipynb ← Barcode count QC
│   ├── 03_dms_reproduction.ipynb        ← Figure 4 reproduction (main)
│   ├── 04_enrichr2_analysis.ipynb       ← EnrichR2 weighted scores
│   └── 05_figures.ipynb                 ← Final publication figures
│
├── src/
│   ├── fitness_utils.py         ← Core analysis functions
│   └── dms_processing.py        ← DMS barcode processing pipeline
│
├── data/
│   └── README.md                ← Data sources & download instructions
│
├── results/
│   ├── figures/                 ← Generated plots (PNG / PDF)
│   └── tables/                  ← Summary CSVs
│
└── thesis/
    └── thesis_report.docx       ← Full thesis document
```

---

## Analysis Overview

### Notebook 03 — DMS Reproduction (`03_dms_reproduction.ipynb`)

Reproduces Figure 4 of Bloom & Neher (2023):

| Step | Description |
|------|-------------|
| 1 | Load Bloom & Neher fitness estimates (`aamut_fitness_all.csv`); filter `expected_count ≥ 20` |
| 2 | Load Spike barcode-variant table (Dadonaite et al. 2023, BA.1 DMS) |
| 3 | Load all variant count CSVs; split VSVG (input) vs no-antibody (output) |
| 4 | Merge counts → compute log₂ enrichment per barcode |
| 5 | Normalise: WT = 0, stop codon = −1 |
| 6 | Load Mpro DMS data (Flynn et al. 2022, eLife) |
| 7 | Merge DMS scores with sequence-based fitness; compute Pearson r |
| 8 | Sensitivity analysis: filter thresholds 5 / 10 / 20 |

**Expected results (matching paper):**
- Spike (Dadonaite et al.): r ≈ 0.664
- Mpro (Flynn et al.): r ≈ 0.528

### Notebook 04 — EnrichR2 Extension (`04_enrichr2_analysis.ipynb`)

Replaces the simple mean-of-log-enrichments with **inverse-variance weighted
means** (the EnrichR2 philosophy):

- Barcodes with high counts → low variance → high weight
- Barcodes with low counts → high variance → low weight  
- No mutation is discarded; noisy measurements are down-weighted instead
- VSVG replicate correlation added as a QC step

---

## Data Sources

All data are fetched at runtime — no files need to be downloaded manually.

| Dataset | Source | URL |
|---------|--------|-----|
| Bloom & Neher fitness | GitHub | `jbloomlab/SARS2-mut-fitness` |
| Spike DMS (Dadonaite 2023) | GitHub | `dms-vep/SARS-CoV-2_Omicron_BA.1_spike_DMS_mAbs` |
| Mpro DMS (Flynn 2022) | eLife CDN | `elifesciences.org/articles/77433` |

See `data/README.md` for details.

---

## References

- Bloom JD & Neher RA (2023). *Fitness effects of mutations to SARS-CoV-2 proteins.* Virus Evolution.
- Dadonaite B et al. (2023). *A pseudovirus system enables deep mutational scanning of the full SARS-CoV-2 spike.* Cell.
- Flynn JM et al. (2022). *Comprehensive fitness landscape of SARS-CoV-2 Mpro reveals insights into viral resistance mechanisms.* eLife.
